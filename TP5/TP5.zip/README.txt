
- El archivo bancoPruebas.txt puede ser modificado pero siempre tendra que tener como terminador ' / '.

- Entre las palabras debe haber un espaciado de línea.

- Las palabras se analizan de a dos, una seguida de la otra. Por lo tanto, si se agrega solo una palabra, se comparará la última palabra con la nada.

- Se decidió usar un puntero al archivo de texto y no meterlo por stdin a fines de mejora estética del programa y multiplicidad de funcionalidades.